<?php

namespace App\Http\Controllers;

use App\Post;
use App\Category;
use App\Tag;
use Illuminate\Http\Request;

class FrontEndController extends Controller
{
    public function findPosts($id){
    	$category = Category::find($id);
    	$posts = $category->posts; 
    	return view("blog.posts", compact('posts'));
    }
}
