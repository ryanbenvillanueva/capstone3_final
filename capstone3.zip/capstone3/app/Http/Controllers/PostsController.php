<?php

namespace App\Http\Controllers;

use App\User;
use App\Tag;
use Session;
use App\Post;
use App\Category;
use Illuminate\Http\Request;

class PostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.posts.index')->with('posts', Post::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();

        $tags = Tag::all();
        
        if($categories->count() == 0 || $tags->count() == 0)
        {
            Session::flash('info', 'You must have some categories and tags before attempting to create a post.');
            return redirect()->back();
        }


        return view('admin.posts.create')->with('categories', $categories)
                                         ->with('tags', $tags);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'title' => 'required|max:255',
            'image' => 'required|image|mimes:jpg,jpeg,png,gif,svg|max:4096',
            'content' => 'required',
            'category_id' => 'required',
            'tags' => 'required'
        ]);

        $image = $request->file('image');

        $image_new_name = time(). "." . $image->getClientOriginalExtension();

        $image->move('uploads/posts', $image_new_name);

        $post = Post::create([
            'title' => $request->title,
            'content' => $request->content,
            'img_path' => '/uploads/posts/'. $image_new_name,
            'category_id' => $request->category_id,
            'slug' => str_slug($request->title)
        ]);

        $post->tags()->attach($request->tags);

        Session::flash('success', 'Post created successfully.');

        return redirect()->route('posts');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $post = Post::find($id);

        return view('admin.posts.edit')->with('post', $post)
                                       ->with('categories', Category::all())
                                       ->with('tags', Tag::all());
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $post = Post::find($id);

        $this->validate($request, [
            'title' => 'required',
            'content' => 'required',
            'category_id' => 'required',
            'image' => 'image|mimes:jpg,jpeg,png,gif,svg|max:4096'
        ]);

        $post->title = $request->title;
        $post->content = $request->content;
        $post->category_id = $request->category_id;
        $post->slug = str_slug($request->title);

        if($request->file('image')!=null){ //if I uploaded another image
    		$image = $request->file('image');
    		$image_new_name = time(). "." .$image->getClientOriginalExtension();
    		$destination ='uploads/posts';
    		$image->move($destination, $image_new_name);
    		$post->img_path = '/uploads/posts/'. $image_new_name;
        }
        
        $post->save();

        $post->tags()->sync($request->tags);
        Session::flash('success', 'Post updated successfully.');

        return redirect()->route('posts');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::find($id);

        $post->delete();

        Session::flash('success', 'The post was just trashed.');

        return redirect()->back();
    }

    public function trashed()
    {
        $posts = Post::onlyTrashed()->get();

        return view('admin.posts.trashed')->with('posts', $posts);
    }

    public function kill($id)
    {
        $post = Post::withTrashed()->where('id', $id)->first();

        $post->forceDelete();

        Session::flash('success', 'Post deleted permanently.');

        return redirect()->back();
    }

    public function restore($id)
    {
        $post = Post::withTrashed()->where('id', $id)->first();

        $post->restore();

        Session::flash('success', 'Post restored successfully.');

        return redirect()->route('posts');
    }

    public function showPosts()
    {
        $posts = Post::all();
        $categories = Category::all();
        $tags = Tag::all();

        return view("blog.posts", compact("posts"))->with('categories', $categories)
                                                   ->with('tags', $tags);
    }

    public function showPostDetail($id)
    {
        $post = Post::find($id);
        $categories = Category::all();
        $tags = Tag::all();
        $user = User::all();

        $next_id = Post::where('id', '>', $post->id)->min('id');
        $prev_id = Post::where('id', '<', $post->id)->max('id');

        return view("blog.post_detail", compact("post"))->with('categories', $categories)
                                                   ->with('tags', $tags)
                                                   ->with('next', Post::find($next_id))
                                                   ->with('prev', Post::find($prev_id));

    }

}
