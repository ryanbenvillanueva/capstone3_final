<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Post extends Model
{
    use SoftDeletes; 
    
    protected $fillable = [
        'title', 'content', 'category_id', 'img_path', 'slug'
    ];

    public function getImg_path($img_path)
    {
        return asset($img_path);
    }
    protected $dates = ['deleted_at'];

    public function category()
    {
        return $this->belongsTo('App\Category');
    }

    public function tags()
    {
        return $this->belongsToMany('App\Tag');
    }
}
