@extends("layouts.template")

@section("content")
<div class="container">
	<div class="jumbotron text-center bg-warning orifont m-0">
		<h1><img src="{{ asset('img/logo.png') }}">{{ $post->title }}<img src="{{ asset('img/logo.png') }}"></h1>
	</div>
	<div class="container  bg-light">
		<div class="col-lg-8 offset-lg-2 py-5">
			@if(Session::has('edit_message'))
			<span>{{ Session::get("edit_message") }}</span>
			@endif
			<div>
				<img class="card-img-top" src="{{ $post->img_path}}" alt="{{ $post->title }}">
			</div>
			<div class="row justify-content-around pt-3">
				<label class="orifont">Category: <span class="text-warning orifont">{{
						$post->category->name }}</span></label>
				<p>Posted on: {{ $post->created_at->toFormattedDateString()
						}}</p>
				<p>Updated on: {{ $post->updated_at->toFormattedDateString()
						}}</p>
			</div>
			<p class="lead">{!!$post->content!!}</p>

			<div class="tags">
				<label class="orifont">Tags: </label>
				@foreach($post->tags as $tag)
				<span class="text-danger orifont" href="">{{ $tag->tag }}</span>
				@endforeach
			</div>
		</div>
		<div class="text-center py-5">
			@if($prev)
				<a href="/blog/posts/{{$prev->id}}" class="btn btn-xs btn-secondary orifont">&laquo; Previous</a>
			@endif
			<a href="/blog/posts" class="btn btn-xs btn-primary orifont">All Blog Posts</a>
			@if($next)
				<a href="/blog/posts/{{$next->id}}" class="btn btn-xs btn-success orifont">Next &raquo;</a>
			@endif
		
		</div>
		<div class="container col-lg-8 offset-lg-2 py-5">
			<div class="text-center">
				<h4 class="lead orifont">Comments</h4>
			</div>
			<div id="disqus_thread"></div>
			<script>
				/**
				 *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
				 *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
				/*
				var disqus_config = function () {
				this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
				this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
				};
				*/
				(function () { // DON'T EDIT BELOW THIS LINE
					var d = document,
						s = d.createElement('script');
					s.src = 'https://foldingbenblog.disqus.com/embed.js';
					s.setAttribute('data-timestamp', +new Date());
					(d.head || d.body).appendChild(s);
				})();
			</script>
			<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by
					Disqus.</a></noscript>

			<script id="dsq-count-scr" src="//foldingbenblog.disqus.com/count.js" async></script>
		</div>
	</div>
</div>
@endsection