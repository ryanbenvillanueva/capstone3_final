<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0" id="hero-banner">
    <div class="jumbotron-fluid text-center text-dark main-container">
        <div class="container">
            <div class="jumbotron bg-warning">
                <h1 class="orifont">FoldingBen Origami</h1>
            </div>
        </div>
        <a class="mt-4 lead btn btn-danger btn-lg text-white border-warning orifont animated pulse infinite" href="<?php echo e(url('/blog/posts')); ?>">Explore and have fun!</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>