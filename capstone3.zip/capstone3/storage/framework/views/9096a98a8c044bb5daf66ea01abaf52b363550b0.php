<?php $__env->startSection("content"); ?>
<div class="container">
	<div class="jumbotron text-center bg-warning orifont m-0">
		<h1><img src="<?php echo e(asset('img/logo.png')); ?>"><?php echo e($category->name); ?><img src="<?php echo e(asset('img/logo.png')); ?>"></h1>
	</div>
	<div class="container  bg-light">
		<div class="col-lg-8 offset-lg-2 py-5">
			<?php if(Session::has('edit_message')): ?>
			<span><?php echo e(Session::get("edit_message")); ?></span>
			<?php endif; ?>
			<!-- <h2 class="card-title"><?php echo e($post->title); ?></h2> -->
			<div>
				<img class="card-img-top" src="<?php echo e($post->img_path); ?>" alt="<?php echo e($post->title); ?>">
			</div>
			<div class="row justify-content-around pt-3">
				<label class="orifont">Category: <a class="btn btn-xs btn-warning card-text orifont" href=""><?php echo e($post->category->name); ?></a></label>
				<p class="orifont">Posted on: <a class="card-text text-dark" href=""><?php echo e($post->created_at->toFormattedDateString()); ?></a></p>
				<p class="orifont">Updated on: <a class="card-text text-dark" href=""><?php echo e($post->updated_at->toFormattedDateString()); ?></a></p>
			</div>
			<p class="lead py-5"><?php echo $post->content; ?></p>

			<div class="tags">
				<label class="orifont">Tags: </label>
				<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a class="btn btn-xs btn-danger orifont" href=""><?php echo e($tag->tag); ?></a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="text-center py-5">
			<a href="#" class="btn btn-xs btn-secondary orifont">&laquo; Previous</a>
		<a href="#" class="btn btn-xs btn-success orifont">Next &raquo;</a>
		</div>
		<div class="container col-lg-8 offset-lg-2">
			<div class="text-center">
				<h4 class="lead orifont">Comments</h4>
			</div>
			<div id="disqus_thread"></div>
			<script>
				/**
				 *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
				 *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
				/*
				var disqus_config = function () {
				this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
				this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
				};
				*/
				(function () { // DON'T EDIT BELOW THIS LINE
					var d = document,
						s = d.createElement('script');
					s.src = 'https://foldingbenblog.disqus.com/embed.js';
					s.setAttribute('data-timestamp', +new Date());
					(d.head || d.body).appendChild(s);
				})();
			</script>
			<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by
					Disqus.</a></noscript>

			<script id="dsq-count-scr" src="//foldingbenblog.disqus.com/count.js" async></script>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.template", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>