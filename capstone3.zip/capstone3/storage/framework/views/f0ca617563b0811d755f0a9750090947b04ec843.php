<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="jumbotron text-center bg-warning orifont m-0">
		<h1><img src="<?php echo e(asset('img/logo.png')); ?>">Blog<img src="<?php echo e(asset('img/logo.png')); ?>"></h1>
	</div>
	<div class="container bg-light">
		<ul class="nav justify-content-around pt-5">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="nav-item text-center">
				<a class="btn btn-lg btn-warning nav-link lead text-dark orifont mx-5" href="#"><?php echo e($category->name); ?></a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<div class="container">
		<div class="row bg-light py-5">
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="offset-lg-1 col-lg-3">
				<img src="<?php echo e($post->img_path); ?>" class="card-img-top">
			</div>
			<div class="offset-lg-1 col-lg-7">
				<div class="row">
					<div class="col-lg-8">
						<h3><?php echo e($post->title); ?></h3>
						<p><?php echo str_limit($post->content, $limit=100); ?></p>
						<a href="posts/<?php echo e($post->id); ?>" class="btn btn-primary">Read More</a>
						<hr>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div> 
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>